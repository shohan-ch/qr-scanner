const TemplatePreviewOne = () => {
  return <></>;
};

export default TemplatePreviewOne;
