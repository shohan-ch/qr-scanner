import "./App.css";
import VcardIndex from "./components/Vcard/VcardIndex";

function App() {
  return (
    <div>
      <VcardIndex />
    </div>
  );
}

export default App;
